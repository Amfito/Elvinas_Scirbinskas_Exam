import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lt.vtmc.exam.Bus;
import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;
import lt.vtmc.exam.SeatIsOccupiedException;
import lt.vtmc.exam.TransportManager;

public class MyExam implements TransportManager {

	List<Bus> buses = new ArrayList<>();
	List<Passenger> passengers = new ArrayList<>();
	
	
	public class nameCompar implements Comparator<Passenger>
	{
		public int compare(Passenger o1, Passenger o2)
		{
			return o1.getName().compareTo(o2.getName());
		}
	}
	
	public class surCompar implements Comparator<Passenger>
	{
		public int compare (Passenger o1, Passenger o2)
		{
			return o1.getSurname().compareTo(o2.getSurname());
		}
	}
	
	public class chainedCompar implements Comparator<Passenger>
	{
		private List<Comparator<Passenger>> listComparators;
		
		public chainedCompar(Comparator<Passenger>... comparators )
		{
			listComparators = Arrays.asList(comparators);
		}
		
		public int compare(Passenger o1, Passenger o2)
		{
			for (Comparator<Passenger> comparator : listComparators)
			{
				int result = comparator.compare(o1, o2);
				if (result != 0)
				{
					return result;
				}
			}
			return 0;
		}
	}
	
	@Override
	public Bus createBus(String busId, int busSeats) {
		
		if (busSeats <= 0 || busId.isEmpty()) throw new IllegalArgumentException();
				
		Bus newBus = new Bus(busId, busSeats);
		buses.add(newBus);
		
		return newBus;
	}

	@Override
	public Passenger createPassenger(String name, String surname, int age) {
		
		if (name.isEmpty() || surname.isEmpty()) throw new IllegalArgumentException();
		
		Passenger newPassenger = new Passenger(name, surname, age);
		passengers.add(newPassenger);
		
		return newPassenger;
	}

	@Override
	public List<Passenger> findPassengersBy(String arg0, PassengerPredicate arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getAveragePassengerAge(String busId) {
		
		List<Passenger> passengersById = getPassengers(busId);
		double ageSum = 0;
		double ageAvg = 0;
		
		for (Passenger obj : passengersById)
			{
				ageSum = ageSum + obj.getAge(); 
			}
		ageAvg = ageSum / passengersById.size();
		
		return ageAvg;
	}

	@Override
	public Bus getBusById(String id) {
		
		if (id == null) throw new IllegalArgumentException();
		
		for (Bus busByID : buses) 
		{
			if (busByID.getId() == id) 
				{
					return busByID;
				}
		}
		return null;
	}

	@Override
	public List<Bus> getCreatedBuses() {
		
		return buses;
	}

	@Override
	public Passenger getOldestPassenger(String busId) {
		
		
		List<Passenger> passengersById = getPassengers(busId);	
		Passenger oldest = null;
		int oldestAge = 0;
		
		for (Passenger obj : passengersById)
		{
			if (obj.getAge() > oldestAge)
			{
				oldest = obj;
			}
		}
		
		
		return oldest;
	}

	@Override
	public Collection<Passenger> getOrderedPassengers(String busId) {
		
		List<Passenger> passengersById = getPassengers(busId);
		
		Collections.sort(passengersById, new chainedCompar(new surCompar(), new nameCompar()));
		
		return passengersById;
	}

	@Override
	public List<Passenger> getPassengers(String busId) {
		
		List<Passenger> passengersById = new ArrayList<>();
		passengersById.addAll(getBusById(busId).getPassengers());
		return passengersById;
	}

	@Override
	public void registerPassenger(Bus bus, int seatNo, Passenger passenger) throws SeatIsOccupiedException {
		
		if (bus.isSeatOccupied(seatNo) == true)
		{
			throw new SeatIsOccupiedException();
		}
		else
		{
			bus.registerPassenger(seatNo, passenger);
		}
		

	}

}
