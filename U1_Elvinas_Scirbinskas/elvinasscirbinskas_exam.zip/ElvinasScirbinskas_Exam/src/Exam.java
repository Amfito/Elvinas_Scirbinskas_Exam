import lt.vtmc.exam.TransportManager;
import lt.vtmc.exam.test.BaseTest;

public class Exam extends BaseTest {

	@Override
	protected TransportManager createTransportManager() {
		// TODO Auto-generated method stub
		return new MyExam();
	}

}
